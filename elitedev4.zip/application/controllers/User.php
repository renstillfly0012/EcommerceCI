<?php
defined('BASEPATH') or exit('No direct script access allowed');

class User extends CI_Controller
{
    public function index()
    {
        $data['header'] = "ITEM LIST";
        $this->load->model('Item_model');
        $items = $this->Item_model->getAllItems();

        $data['items'] = $items;
        $this->load->view('include_bs/user_top');
       // $this->load->view('include_bs/nav');
        $this->load->view('user/user_dashboard', $data);
        $this->load->view('include_bs/user_bottom');
    }
}