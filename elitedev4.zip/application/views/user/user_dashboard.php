<div class="container">
    <nav class="navbar navbar-expand-lg navbar-light bg-light fixed-top">
        <div class="container">
            <a class="navbar-brand" href="#">Computer Parts and Accessories</a>
            <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarResponsive" aria-controls="navbarResponsive" aria-expanded="false" aria-label="Toggle navigation">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse" id="navbarResponsive">
                <ul class="navbar-nav ml-auto">
                    <li class="nav-item active">
                        <a class="nav-link" href="#home">Home
                            <span class="sr-only">(current)</span>
                        </a>
                    </li>
                    <li class="nav-item">
                        
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="#">Place Order</a>
                    </li>
                </ul>
            </div>
        </div>
    </nav>
</div>


    <div class="row" style="margin-top:10%;">
    <?php foreach ($items as $item) : ?>
        <div class="col-md-4">
            <figure class="card card-product">
                <div class="img-wrap"><img src="https://www.laptopsdirect.co.uk/Images/LC27F591FDUXEN_1_Supersize.jpg?width=700&height=700&v=2"></div>
                <figcaption class="info-wrap">
                    <h4 class="title"><?= $item->name ?></h4>
                    <p class="desc">Some small description goes here</p>
                    <div class="rating-wrap">
                        <div class="label-rating">132 reviews</div>
                        <div class="label-rating">154 orders </div>
                    </div> <!-- rating-wrap.// -->
                </figcaption>
                <div class="bottom-wrap">
                    <a href="" class="btn btn-sm btn-primary float-right" data-toggle="modal" data-target="#Modal1">Order Now</a>
                    <div class="price-wrap h5">
                        <span class="price-new"><?= $item->price ?></span> <del class="price-old">$1980</del>
                    </div> <!-- price-wrap.// -->
                </div> <!-- bottom-wrap.// -->
            </figure>
        </div> <!-- col // -->
        <?php endforeach?>
       


    <div class="modal fade" id="Modal1" tabindex="-1" role="dialog" aria-modal="true">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title">Modal title</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">×</span>
        </button>
      </div>
      <div class="modal-body">
        <div class="card shadow border-0">
          <img class="card-img-top" src="https://www.laptopsdirect.co.uk/Images/LC27F591FDUXEN_1_Supersize.jpg?width=700&amp;height=700&amp;v=2" alt="Card image cap">
          <div class="card-body">
            <h5 class="card-title">SAMSUNG - C27F591 Full HD 27" Curved LED Monitor</h5>
            <p class="card-text">This is a longer card with supporting text below as a natural lead-in to additional content. This content is a little bit longer.</p>
          </div>
          <div class="modal-footer">
            <button type="button" class="btn btn-warning">Add to Cart</button>
            <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
          </div>
        </div>
      </div>
    </div>
