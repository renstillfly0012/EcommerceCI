<header id="home">
  <div id="carouselExampleIndicators" class="carousel slide" data-ride="carousel">
    <ol class="carousel-indicators">
      <li data-target="#carouselExampleIndicators" data-slide-to="0" class="active"></li>
      <li data-target="#carouselExampleIndicators" data-slide-to="1"></li>
      <li data-target="#carouselExampleIndicators" data-slide-to="2"></li>
    </ol>
    <div class="carousel-inner" role="listbox">
      <!-- Slide One - Set the background image for this slide in the line below -->
      <div class="carousel-item active" style="background-image: url('https://i.imgur.com/dvaAt5s.jpg')">
        <div class="carousel-caption d-none d-md-block">
          <h2 class="display-4">First Slide</h2>
          <p class="lead">This is a description for the first slide.</p>
        </div>
      </div>
      <!-- Slide Two - Set the background image for this slide in the line below -->
      <div class="carousel-item" style="background-image: url('https://i.imgur.com/Tu5zoCH.jpg')">
        <div class="carousel-caption d-none d-md-block">
          <h2 class="display-4">Second Slide</h2>
          <p class="lead">This is a description for the second slide.</p>
        </div>
      </div>
      <!-- Slide Three - Set the background image for this slide in the line below -->
      <div class="carousel-item" style="background-image: url('https://i.imgur.com/zNICG8Q.jpg')">
        <div class="carousel-caption d-none d-md-block">
          <h2 class="display-4">Third Slide</h2>
          <p class="lead">This is a description for the third slide.</p>
        </div>
      </div>
    </div>
    <a class="carousel-control-prev" href="#carouselExampleIndicators" role="button" data-slide="prev">
      <span class="carousel-control-prev-icon" aria-hidden="true"></span>
      <span class="sr-only">Previous</span>
    </a>
    <a class="carousel-control-next" href="#carouselExampleIndicators" role="button" data-slide="next">
      <span class="carousel-control-next-icon" aria-hidden="true"></span>
      <span class="sr-only">Next</span>
    </a>
  </div>
</header>

<section class="main">
  <div class="container mt-4">
    <h1 class="text-center mb-4 p-4 text-secondary"></h1>
    <div class="row">

      <div class="card-columns">
       
      

        <div class="card shadow border-0">
          <img class="card-img-top" src="https://www.laptopsdirect.co.uk/Images/LC27F591FDUXEN_1_Supersize.jpg?width=700&height=700&v=2" alt="Card image cap">
          <div class="card-body">
            <h5 class="card-title">SAMSUNG - C27F591 Full HD 27" Curved LED Monitor</h5>
            <p class="card-text">This is a longer card with supporting text below as a natural lead-in to additional content. This content is a little bit longer.</p>
          </div>
          <div class="card-footer">
            <button type="button" class="btn btn-outline-info" data-toggle="modal" data-target="#Modal1">
              View Item
            </button>
          </div>
        </div>

 
        
        <div class="card shadow border-0">
          <img class="card-img-top" src="https://www.gtomegaracing.com/image/cache/catalog/1ginx/700x700%20Black%20next%20Red%20PVC-700x700.jpg" alt="Card image cap">
          <div class="card-body">
            <h5 class="card-title">GT Omega PRO Racing Office Chair Black Next Red Leather</h5>
            <p class="card-text">This is a longer card with supporting text below as a natural lead-in to additional content. This content is a little bit longer.</p>
          </div>
          <div class="card-footer">
            <button type="button" class="btn btn-outline-info" data-toggle="modal" data-target="#Modal">
              View Item
            </button>
          </div>
        </div>

        <div class="card shadow border-0">
          <img class="card-img-top" src="https://images-na.ssl-images-amazon.com/images/I/817DTJ1sDWL._SX425_.jpg" alt="Card image cap">
          <div class="card-body">
            <h5 class="card-title">Steeleries Siberia 350</h5>
            <p class="card-text">This is a longer card with supporting text below as a natural lead-in to additional content. This content is a little bit longer.</p>
          </div>
          <div class="card-footer">
            <button type="button" class="btn btn-outline-info" data-toggle="modal" data-target="#Modal3">
              View Item
            </button>
          </div>
        </div>

        <div class="card shadow border-0">
          <img class="card-img-top" src="https://images-na.ssl-images-amazon.com/images/I/81kf5XBjQML._SX425_.jpg" alt="Card image cap">
          <div class="card-body">
            <h5 class="card-title">Steelseries Apex M800</h5>
            <p class="card-text">This is a longer card with supporting text below as a natural lead-in to additional content. This content is a little bit longer.</p>
          </div>
          <div class="card-footer">
            <button type="button" class="btn btn-outline-info">View Item</button>
          </div>
        </div>

        <div class="card shadow border-0">
          <img class="card-img-top" src="https://c1.neweggimages.com/NeweggImage/ProductImage/26-249-206-14.jpg" alt="Card image cap">
          <div class="card-body">
            <h5 class="card-title">Steelseries Rival 700</h5>
            <p class="card-text">This is a longer card with supporting text below as a natural lead-in to additional content. This content is a little bit longer.</p>
          </div>
          <div class="card-footer">
            <button type="button" class="btn btn-outline-info">View Item</button>
          </div>
        </div>

        <div class="card shadow border-0">
          <img class="card-img-top" src="https://c1.neweggimages.com/ProductImage/26-995-023-04.jpg" alt="Card image cap">
          <div class="card-body">
            <h5 class="card-title">Steelseries QcK</h5>
            <p class="card-text">This is a longer card with supporting text below as a natural lead-in to additional content. This content is a little bit longer.</p>
          </div>
          <div class="card-footer">
            <button type="button" class="btn btn-outline-info">View Item</button>
          </div>
        </div>

        <div class="card shadow border-0">
          <img class="card-img-top" src="https://images-na.ssl-images-amazon.com/images/I/41DNsSq6vZL._SY355_.jpg" alt="Card image cap">
          <div class="card-body">
            <h5 class="card-title">BitFenix Aurora Desktop White</h5>
            <p class="card-text">This is a longer card with supporting text below as a natural lead-in to additional content. This content is a little bit longer.</p>
          </div>
          <div class="card-footer">
            <button type="button" class="btn btn-outline-info">View Item</button>
          </div>
        </div>

        <div class="card shadow border-0">
          <img class="card-img-top" src="https://images-na.ssl-images-amazon.com/images/I/51uI1khXouL._SX425_.jpg" alt="Card image cap">
          <div class="card-body">
            <h5 class="card-title">NVIDIA GeForce GTX 970 (MSI)</h5>
            <p class="card-text">This is a longer card with supporting text below as a natural lead-in to additional content. This content is a little bit longer.</p>
          </div>
          <div class="card-footer">
            <button type="button" class="btn btn-outline-info">View Item</button>
          </div>
        </div>

        <div class="card shadow border-0">
          <img class="card-img-top" src="https://image-us.samsung.com/SamsungUS/pim/migration/computing/memory-storage/solid-state-drives/mz-7ke512bw/Pdpgallery-mz-7ke512bw-600x600-C6-052016.jpg?$product-details-jpg$" alt="Card image cap">
          <div class="card-body">
            <h5 class="card-title">Samsung SSD 850 PRO 512GB (SSD)</h5>
            <p class="card-text">This is a longer card with supporting text below as a natural lead-in to additional content. This content is a little bit longer.</p>
          </div>
          <div class="card-footer">
            <button type="button" class="btn btn-outline-info">View Item</button>
          </div>
        </div>

        <div class="card shadow border-0">
          <img class="card-img-top" src="https://images-na.ssl-images-amazon.com/images/I/81aGFvmR3VL._SX425_PIbundle-4,TopRight,0,0_AA425SH20_.jpg" alt="Card image cap">
          <div class="card-body">
            <h5 class="card-title">16.0GB Dual-Channel DDR3 2400MHZ</h5>
            <p class="card-text">This is a longer card with supporting text below as a natural lead-in to additional content. This content is a little bit longer.</p>
          </div>
          <div class="card-footer">
            <button type="button" class="btn btn-outline-info">View Item</button>
          </div>
        </div>

        <div class="card shadow border-0">
          <img class="card-img-top" src="https://asset.msi.com/resize/image/global/product/five_pictures6_2838_20130528115044.png62405b38c58fe0f07fcef2367d8a9ba1/380.png" alt="Card image cap">
          <div class="card-body">
            <h5 class="card-title">MSI Z87-GD65 GAMING (MS-7845)</h5>
            <p class="card-text">This is a longer card with supporting text below as a natural lead-in to additional content. This content is a little bit longer.</p>
          </div>
          <div class="card-footer">
            <button type="button" class="btn btn-outline-info">View Item</button>
          </div>
        </div>

        <div class="card shadow border-0">
          <img class="card-img-top" src="https://c1.neweggimages.com/NeweggImage/ProductImage/19-116-896-04.jpg" alt="Card image cap">
          <div class="card-body">
            <h5 class="card-title">Intel Core i5 4570</h5>
            <p class="card-text">This is a longer card with supporting text below as a natural lead-in to additional content. This content is a little bit longer.</p>
          </div>
          <div class="card-footer">
            <button type="button" class="btn btn-outline-info">View Item</button>
          </div>
        </div>

      </div>
    </div>
  </div>
</div>
</section>

 
<header class="bg-primary text-center py-5 mb-4" id="about">
  <div class="container">
    <h1 class="font-weight-light text-white">&#169;Copyright 2019</h1>
  </div>
</header>

<!-- Page Content -->
<!--<div class="container">-->
<!--  <div class="row">-->
    <!-- Team Member 1 -->
<!--    <div class="col-xl-3 col-md-6 mb-4">-->
<!--      <div class="card border-0 shadow">-->
<!--        <img src="https://source.unsplash.com/TMgQMXoglsM/500x350" class="card-img-top" alt="...">-->
<!--        <div class="card-body text-center">-->
<!--          <h5 class="card-title mb-0">Team Member</h5>-->
<!--          <div class="card-text text-black-50">Web Developer</div>-->
<!--        </div>-->
<!--      </div>-->
<!--    </div>-->
    <!-- Team Member 2 -->
<!--    <div class="col-xl-3 col-md-6 mb-4">-->
<!--      <div class="card border-0 shadow">-->
<!--        <img src="https://source.unsplash.com/9UVmlIb0wJU/500x350" class="card-img-top" alt="...">-->
<!--        <div class="card-body text-center">-->
<!--          <h5 class="card-title mb-0">Team Member</h5>-->
<!--          <div class="card-text text-black-50">Web Developer</div>-->
<!--        </div>-->
<!--      </div>-->
<!--    </div>-->
    <!-- Team Member 3 -->
<!--    <div class="col-xl-3 col-md-6 mb-4">-->
<!--      <div class="card border-0 shadow">-->
<!--        <img src="https://source.unsplash.com/sNut2MqSmds/500x350" class="card-img-top" alt="...">-->
<!--        <div class="card-body text-center">-->
<!--          <h5 class="card-title mb-0">Team Member</h5>-->
<!--          <div class="card-text text-black-50">Web Developer</div>-->
<!--        </div>-->
<!--      </div>-->
<!--    </div>-->
    <!-- Team Member 4 -->
<!--    <div class="col-xl-3 col-md-6 mb-4">-->
<!--      <div class="card border-0 shadow">-->
<!--        <img src="https://source.unsplash.com/ZI6p3i9SbVU/500x350" class="card-img-top" alt="...">-->
<!--        <div class="card-body text-center">-->
<!--          <h5 class="card-title mb-0">Team Member</h5>-->
<!--          <div class="card-text text-black-50">Web Developer</div>-->
<!--        </div>-->
<!--      </div>-->
<!--    </div>-->
<!--  </div>-->
  <!-- /.row -->

<!--</div>-->

<!--<div class="container">-->
<!--  <div class="row">-->
<!--   <div class="col-md-8">-->
<!--    <blockquote class="blockquote text-center mb-0">-->
<!--      <svg class="lnr text-muted quote-icon pull-left">-->
<!--        <use xlink:href="#lnr-heart">                                       -->
<!--        </use></svg>-->
<!--        <p class="mb-0">Keep in touch with me for more Theme  right here!</p>-->
<!--        <footer class="blockquote-footer">Luckmoshy Designing-->
<!--          <cite title="Source Title">Webublog @</cite>-->
<!--        </footer>-->
<!--      </blockquote>-->
<!--    </div>-->
<!--    <div class="col-md-4">-->
<!--      <a class="flot-right btn btn-white border-0 rounded shadow post-pager-link p-0 next ml-4" href="">-->
<!--       <span class="d-flex h-100">-->
<!--        <span class="p-3 d-flex flex-column justify-content-center w-100">-->
<!--          <div class="indicator mb-1 text-uppercase text-muted">webublog<i class="fa fa-bars ml-2"></i></div>-->
<!--          <p class="f-13">See next awesome themes</p>-->
<!--        </span>-->
<!--        <span class="bg-primary p-2 d-flex align-items-center text-white">-->
<!--         <i class="fa fa-arrow-circle-right"></i>-->
<!--       </span>-->
<!--     </span>-->
<!--   </a></div>-->
<!-- </div>-->

</div>



<!-- Modal1 -->
<div class="modal" id="Modal1" tabindex="-1" role="dialog">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title">Modal title</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">×</span>
        </button>
      </div>
      <div class="modal-body">
        <div class="card shadow border-0">
          <img class="card-img-top" src="https://www.laptopsdirect.co.uk/Images/LC27F591FDUXEN_1_Supersize.jpg?width=700&height=700&v=2" alt="Card image cap">
          <div class="card-body">
            <h5 class="card-title">SAMSUNG - C27F591 Full HD 27" Curved LED Monitor</h5>
            <p class="card-text">This is a longer card with supporting text below as a natural lead-in to additional content. This content is a little bit longer.</p>
          </div>
          <div class="modal-footer">
            <button type="button" class="btn btn-warning">Add to Cart</button>
            <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
          </div>
        </div>
      </div>
    </div>

    <!-- Modal2 -->
    <div class="modal" id="Modal" tabindex="-1" role="dialog">
      <div class="modal-dialog" role="document">
        <div class="modal-content">
          <div class="modal-header">
            <h5 class="modal-title">Chair</h5>
            <button type="button" class="close" data-dismiss="modal" aria-label="Close">
              <span aria-hidden="true">×</span>
            </button>
          </div>
          <div class="modal-body">
            <div class="card shadow border-0">
              <img class="card-img-top" src="https://www.laptopsdirect.co.uk/Images/LC27F591FDUXEN_1_Supersize.jpg?width=700&height=700&v=2" alt="Card image cap">
              <div class="card-body">
                <h5 class="card-title">asddas.</p>
                </div>
                <div class="modal-footer">
                  <button type="button" class="btn btn-warning">Add to Cart</button>
                  <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                </div>
              </div>
            </div>
          </div>

          <!-- Modal3 -->
          <div class="modal" id="Modal3" tabindex="-1" role="dialog">
            <div class="modal-dialog" role="document">
              <div class="modal-content">
                <div class="modal-header">
                  <h5 class="modal-title">Modal title</h5>
                  <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">×</span>
                  </button>
                </div>
                <div class="modal-body">
                  <div class="card shadow border-0">
                    <img class="card-img-top" src="https://www.laptopsdirect.co.uk/Images/LC27F591FDUXEN_1_Supersize.jpg?width=700&height=700&v=2" alt="Card image cap">
                    <div class="card-body">
                      <h5 class="card-title">SAMSUNG - C27F591 Full HD 27" Curved LED Monitor</h5>
                      <p class="card-text">This is a longer card with supporting text below as a natural lead-in to additional content. This content is a little bit longer.</p>
                    </div>
                    <div class="modal-footer">
                      <button type="button" class="btn btn-warning">Add to Cart</button>
                      <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                    </div>
                  </div>
                </div>
              </div>


