<?php
defined('BASEPATH') OR exit('No direct script access allowed');

$config['footer'] = 'owned by ABC Company';
$config['footer2'] = 'owned by XYZ Company';

